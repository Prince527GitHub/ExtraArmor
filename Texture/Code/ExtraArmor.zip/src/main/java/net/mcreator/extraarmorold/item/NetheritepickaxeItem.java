
package net.mcreator.extraarmorold.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;

import net.mcreator.extraarmorold.itemgroup.ExtraArmorItemGroup;
import net.mcreator.extraarmorold.ExtraarmoroldModElements;

@ExtraarmoroldModElements.ModElement.Tag
public class NetheritepickaxeItem extends ExtraarmoroldModElements.ModElement {
	@ObjectHolder("extraarmorold:netheritepickaxe")
	public static final Item block = null;
	public NetheritepickaxeItem(ExtraarmoroldModElements instance) {
		super(instance, 35);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new PickaxeItem(new IItemTier() {
			public int getMaxUses() {
				return 100;
			}

			public float getEfficiency() {
				return 9f;
			}

			public float getAttackDamage() {
				return 5.199999999999999f;
			}

			public int getHarvestLevel() {
				return 3;
			}

			public int getEnchantability() {
				return 12;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(NetheriteingotItem.block, (int) (1)));
			}
		}, 1, -2.7999999999999998f, new Item.Properties().group(ExtraArmorItemGroup.tab)) {
		}.setRegistryName("netheritepickaxe"));
	}
}


package net.mcreator.extraarmorold.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;

import net.mcreator.extraarmorold.itemgroup.ExtraArmorItemGroup;
import net.mcreator.extraarmorold.ExtraarmoroldModElements;

@ExtraarmoroldModElements.ModElement.Tag
public class NetheriteSwordItem extends ExtraarmoroldModElements.ModElement {
	@ObjectHolder("extraarmorold:netherite_sword")
	public static final Item block = null;
	public NetheriteSwordItem(ExtraarmoroldModElements instance) {
		super(instance, 43);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new SwordItem(new IItemTier() {
			public int getMaxUses() {
				return 2031;
			}

			public float getEfficiency() {
				return 4f;
			}

			public float getAttackDamage() {
				return 6f;
			}

			public int getHarvestLevel() {
				return 1;
			}

			public int getEnchantability() {
				return 2;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(NetheriteingotItem.block, (int) (1)));
			}
		}, 3, -2.4f, new Item.Properties().group(ExtraArmorItemGroup.tab)) {
		}.setRegistryName("netherite_sword"));
	}
}

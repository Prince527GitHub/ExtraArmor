
package net.mcreator.extraarmorold.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.extraarmorold.item.LOGOItem;
import net.mcreator.extraarmorold.ExtraarmoroldModElements;

@ExtraarmoroldModElements.ModElement.Tag
public class ExtraArmorItemGroup extends ExtraarmoroldModElements.ModElement {
	public ExtraArmorItemGroup(ExtraarmoroldModElements instance) {
		super(instance, 1);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabextra_armor") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(LOGOItem.block, (int) (1));
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static ItemGroup tab;
}

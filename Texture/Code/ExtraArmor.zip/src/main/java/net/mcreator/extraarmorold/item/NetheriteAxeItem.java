
package net.mcreator.extraarmorold.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.item.AxeItem;

import net.mcreator.extraarmorold.itemgroup.ExtraArmorItemGroup;
import net.mcreator.extraarmorold.ExtraarmoroldModElements;

@ExtraarmoroldModElements.ModElement.Tag
public class NetheriteAxeItem extends ExtraarmoroldModElements.ModElement {
	@ObjectHolder("extraarmorold:netherite_axe")
	public static final Item block = null;
	public NetheriteAxeItem(ExtraarmoroldModElements instance) {
		super(instance, 47);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new AxeItem(new IItemTier() {
			public int getMaxUses() {
				return 2031;
			}

			public float getEfficiency() {
				return 8f;
			}

			public float getAttackDamage() {
				return 2f;
			}

			public int getHarvestLevel() {
				return 3;
			}

			public int getEnchantability() {
				return 10;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.EMPTY;
			}
		}, 1, -3f, new Item.Properties().group(ExtraArmorItemGroup.tab)) {
		}.setRegistryName("netherite_axe"));
	}
}

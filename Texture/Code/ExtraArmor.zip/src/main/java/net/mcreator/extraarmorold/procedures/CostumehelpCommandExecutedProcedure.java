package net.mcreator.extraarmorold.procedures;

import net.minecraftforge.fml.server.ServerLifecycleHooks;

import net.minecraft.util.text.StringTextComponent;
import net.minecraft.server.MinecraftServer;

import net.mcreator.extraarmorold.ExtraarmoroldModElements;

import java.util.Map;

@ExtraarmoroldModElements.ModElement.Tag
public class CostumehelpCommandExecutedProcedure extends ExtraarmoroldModElements.ModElement {
	public CostumehelpCommandExecutedProcedure(ExtraarmoroldModElements instance) {
		super(instance, 42);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		{
			MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
			if (mcserv != null)
				mcserv.getPlayerList().sendMessage(new StringTextComponent("What is ExtraArmor it's not what the name is."));
		}
		{
			MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
			if (mcserv != null)
				mcserv.getPlayerList().sendMessage(new StringTextComponent("1. It adds 1.17 and 1.16 stuff in to Minecraft 1.15.2"));
		}
		{
			MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
			if (mcserv != null)
				mcserv.getPlayerList().sendMessage(new StringTextComponent("2. It adds more armor and tools"));
		}
		{
			MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
			if (mcserv != null)
				mcserv.getPlayerList().sendMessage(new StringTextComponent("3. it adds new ore and more"));
		}
		{
			MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
			if (mcserv != null)
				mcserv.getPlayerList().sendMessage(new StringTextComponent("YOU NEED TO DO /hell"));
		}
	}
}
